
package thanosandstones;

/**
 *
 * @author bejgum akshara
 */
import java.util.Scanner;
public class ThanosAndStones {

    
    public static void main(String[] args) {
        // TODO code application logic here
        //initialize the game
        int score=0;
        String command="";
        int planet=1;/*every planet has a stone
                    captain america kept those stones hidden
                     now thanos gonna find them(you) by asking bad 
                     person on that planet
                  */
        boolean hasStone=false;
       
        Scanner scan=new Scanner(System.in);
        
            //print room info
            while(true){
            if(planet==1){
               System.out.println("you are in Sarkar planet.");
               System.out.println("you met ur friend1.who tell u about magic stick");
                
            }
            else if(planet==2){
                System.out.println("you are in Xander planet.");
               System.out.println("magic stick glows when you move towards south.it doesnt glow when you turn towards east.");
                
            }
            else if(planet==3){
                System.out.println("you are in nova planet.");
               
               System.out.println("magic stick glows when you move towards north.it doesnt glow when you turn towards east.");
                System.out.println("if u got this this ends the game");
            }
            System.out.print("You have :");
            if(hasStone){
                System.out.print("Stone ");
            }
            System.out.println();
            System.out.println("Score :"+score);
            //get player command
            System.out.print("->");
            command=scan.nextLine();
            
            //deal with player input
            if(planet==1){
                if(command.equals("ask that person")){
                    System.out.println("every planet has a stone.");
                    System.out.println("you need to find them and destroy this world my lord.");
                    System.out.println("here is a magic stick which glows whenever a stone nearby.");
                   
                    score+=10;
                    hasStone=true;
                   
                }
                else if(command.equals("examine the stone box")){
                    System.out.println("Box has a writing.it says'if u have this box,You need to left your loved one here!!!");
                    
                }
                else if(command.equals("left my daughter")){
                    System.out.println("you will wake up in water.");
                    planet=2;
                    score+=10;
                    
                    
                }
                else{
                    System.out.println("sorry,I dont know how to do that");
                }
            }
            else if(planet==2){
                if(command.equals("south"))
                {
                    System.out.println("You got other stone.");
                    score+=10;
                    hasStone=true;
                   
                }
                else if(command.equals("got the second stone")){
                    planet=3;
                }
                else{
                    System.out.println("dont know what to do!!!");
                }
            }
                else if(planet==3){
                if(command.equals("north"))
                {
                    System.out.println("haha got the final stone.now i can destroy the world");
                    
                    score+=10;
                    hasStone=true;
                    System.out.println("Winner !!!!on the top of world.....");
                    
                }
                }
               
            
                else{
                    System.out.println("Looser!!!");
                }
            
                    
        
        
        
        
        
        
            } 
        
    
}
}
